function ChiTietSanPham()
{
    return(
    <>
    <thead>
        <div class="header-product-details">
            <span>
                <div class="sale-product-details">
                    <span>GIẢM GIÁ</span>
                    <span>40%</span>
                    <span>30%</span>
                    <span>25%</span>
                    <span>20%</span>
                    <div class="search-product-details">
                        <input type="search"id="" placeholder="Tìm kiếm"/>
                        <button class="search-product">Tìm</button>
                    </div>
                </div>            
            </span>
        </div>
    </thead>
    <tbody>
        <div class="main-product-details">          
            <div class="info-product-details">
                <h2>CHI TIẾT SẢN PHẨM</h2>
                <div class="info-product">
                    <div class="img-product-details">
                        <img src="/adidas1.jpg"/>
                    </div>
                    <span>Tên sản phẩm: </span><br/>
                    <span>Giá bán: </span><br/>
                    <span>Mô tả:</span>
                    <span>- Thiết kế bằng chất liệu vải thật.</span><br/>
                    <span> - Nhỏ gọn phù hợp form chân.</span><br/>
                    <span>- Đế cao su trượt an toàn.</span><br/>
                </div>
                <div class="size-product">
                    <span>SIZE:</span>
                    <div class="btn-size">
                        <button class="btn-size-product">37</button>
                        <button class="btn-size-product">38</button>
                        <button class="btn-size-product">39</button>
                        <button class="btn-size-product">40</button>
                    </div>
                </div>
                <div class="amount-product-details">
                    <input type="number"/>
                </div>

                <div class="btn-buyProduct">
                    <button class="btn-buyNow">MUA NGAY</button>
                </div>
                <div class="tilte-product-details">
                    <span>
                        Xin cam kết về chất lượng sản phẩm. Chúng tôi tuyệt đối không bán hàng fake,
                        hàng kém chất lượng. Nếu quý khách nhận thấy hàng lỗi hoặc không đúng như cam kết.
                        Chúng tôi sẽ tiến hành cho đổi trả và hoàn lại tiền 100%.
                    </span>
                </div>
            </div>
        </div>
    </tbody>
    </>
    );
}
export default ChiTietSanPham;