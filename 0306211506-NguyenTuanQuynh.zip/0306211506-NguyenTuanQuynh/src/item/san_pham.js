import { NavLink } from "react-router-dom";

function SanPham(props){
    const lstPd = props.pd.map(function(item){
        return(
            <>
            <div className="lstSP">
                <div className="border border-dark">
                    <NavLink to="/ChiTietSanPham"><img src={item.hinh_anh} className="hinh_anh"/></NavLink>
                    {/* <img src={item.hinh_anh} className="hinh_anh"/> */}
                    <p><span className="ten">{item.ten}</span></p>
                    <p><span className="gia">{item.gia}</span></p>
                    <button className="btn_mua">Chọn Mua</button>
                </div>
            </div>         
            </>
        );
    });
    return(
        <>
        <div className="title_pd">
            <span className="type_name h3">{props.typename}</span>
         </div>
        <div className="wrapper-product">
            {lstPd}
        </div>  
        </>
    );
}
export default SanPham;