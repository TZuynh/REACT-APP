import SanPham from "./san_pham";
import {useEffect} from 'react';
import { useState } from "react";
function LoaiSanPham(){
    
    //Du lieu
    const [dsloaisp, setdsloaisp] = useState([]) 
    useEffect(() =>{
        fetch('http://localhost:9000/get-data.php')
        .then(response => response.json())
        .then(json => setdsloaisp(json))
    }, []);   
    
    const lstSP = dsloaisp.map(function(item){
        return(
            <SanPham typename={item.typename} pd={item.pd}/>
        );
    });
    return(
        <>
        <div className="lstSPALL">
            {lstSP}
        </div>
        </>
    );
};
export default LoaiSanPham;