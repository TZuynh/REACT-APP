import GioHang from "../pages/gio_hang";
function ThanhToan(){
    return(
        <>
        <GioHang/>
        </>
        );
}
export default ThanhToan;