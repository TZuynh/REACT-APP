import {useEffect} from 'react';
import { useState } from "react";
import Header from './header';
import Banner from './banner';
import NewsPageMini from './mini_newspage';
import Footer from './footer';
function NewsPage(){
    const [data, setdata] = useState([]);
    useEffect(() =>{
        fetch('http://localhost:9000/newspage-data.php')
        .then(response => response.json())
        .then(json => setdata(json))
    }, []);
    const lstpage = data.map(function(item){
        return(
            <NewsPageMini namepage={item.namepage} lstpages={item.lstpages}/>
        );
    });
    return(
        <>
        <div className='main-newspage'>
            <Header/>
            <Banner/>
            {lstpage}
            <Footer/>
        </div>      
        </>
    );
}
export default NewsPage;