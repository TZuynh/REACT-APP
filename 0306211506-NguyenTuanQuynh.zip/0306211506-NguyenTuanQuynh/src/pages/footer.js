function Footer()
{
    return(
    <footer>

    <div class="footer">
        <div className="about">
        <h2>ABOUT</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum consequatur ea suscipit asperiores. 
        Possimus sequi atque quae numquam, beatae, animi neque asperiores commodi dolores, provident vel voluptate ipsa libero nihil.</p>
        </div>
        <div class="contact-page">
            <h2>CONTACT</h2>
            <p>Address: NKKN, Q3, TP.HCM</p>
            <p>Phone: 0293293234</p>
            <p>Email: abc@gmail.com</p>
        <div className="copy">
                CopyRight@ NguyenTuanQuynh
        </div>    
        </div>
    </div>
    </footer>
    );
}
export default Footer;