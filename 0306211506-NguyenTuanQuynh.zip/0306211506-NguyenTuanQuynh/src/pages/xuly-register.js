import Register from "./register";
export default function XuLyDangKy(){
    return(
        <>
        <Register/>
        </>
    );
}