import Login from "./login";
export default function XuLyDangNhap(){
    return(
        <>
        <Login/>
        </>
    );
}