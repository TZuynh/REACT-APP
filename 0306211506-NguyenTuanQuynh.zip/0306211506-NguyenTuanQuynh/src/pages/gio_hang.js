function GioHang(){
    return(
        <div class="main-gio_hang">
            <h1 class="font-product">Giỏ Hàng Sản Phẩm</h1>
            <div class="header-product">
                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas1.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas2.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas3.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas1.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas2.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas3.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>

                <div class="img-product">
                    <div class="info-product">
                        <img class="imgsp" src="adidas1.jpg"/>
                        <br/>
                        <span>Tên: ADIDAS S</span>
                        <br/>
                        <span>Số lượng:</span>
                        <input type="number" value="1" class="sl"/>
                        <br/>
                        <span>Thành tiền: 1000$</span>
                        <br/>
                        <button class="btn-edit">Edit</button>
                        <button class="btn-delete">Delete</button>
                    </div>
                </div>
            </div>
            <div class="total-right-btn">
                <button class="btn-rebuy">Tiếp Tục Mua Hàng</button>
                <button class="btn-total">Thanh Toán</button>
            </div>   
            </div>
    );
}
export default GioHang;