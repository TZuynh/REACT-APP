import ChiTietSanPham from "../item/chi_tiet_san_pham";
export default function XulyChiTietSanPham(){
    return(
        <>
        <ChiTietSanPham/>
        </>
    );
}