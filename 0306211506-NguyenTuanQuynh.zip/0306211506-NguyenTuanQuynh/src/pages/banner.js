export default function Banner(){
    return(
    <div className="banner-product">
        <div id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-inner ">
                <div className="carousel-item active" >
                <img src="/cr7_background.jpg" className="card-img-top  " alt="..."/> 
            </div>
        </div>
        </div>       
    </div>
    );
}